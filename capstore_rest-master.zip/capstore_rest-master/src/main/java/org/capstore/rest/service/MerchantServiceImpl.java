package org.capstore.rest.service;

import java.util.List;
import java.util.Optional;

import org.capstore.rest.dao.MerchantDao;
import org.capstore.rest.model.Merchant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class MerchantServiceImpl implements MerchantService {
	@Autowired
    private MerchantDao merchantDao;
	
	public List<Merchant> getAllMerchant() {
		return (List<Merchant>) merchantDao.findAll();
	}

	public  Merchant findMerchantById(Integer merchantId) {
		return merchantDao.getOne(merchantId);
	}

	public void saveMerchant(Merchant merchant) {
		merchantDao.save(merchant);
	}

	public void deleteMerchant(Integer merchantId) {
		merchantDao.deleteById(merchantId);
	}

	public List<Merchant> getAllMerchant1() {
		return (List<Merchant>) merchantDao.findAllByActive();
	}

}
